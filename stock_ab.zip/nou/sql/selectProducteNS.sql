create procedure selectProducteNS(NS varchar(50))
returns (idProducteQueTenim integer, codi varchar(20), Numserie varchar(50), descripcio varchar (150))
as begin
   for
    select u.idProducteQueTenim,g.codi, u.NS, g.descripcio
      from producte g
	join ProducteQueTenim u on (g.idproducte=u.idproducte) 
	  where NS like '%:NS%' or :NS is null
	     into :idProducteQueTenim,:codi, :Numserie, :descripcio
   do suspend;
END^







