alter procedure buscaproducte(idtipus integer, idfamilia integer, descr varchar(150))
 returns (idproducte integer, codi varchar(20), descripcio varchar(150), preu float,  idtip integer, idfam integer, idmarca integer, idproveidor integer)
  as begin
   for
    select idproducte,codi, descripcio,preu, idtipus, idfamilia, idmarca, idproveidor
      from producte where (idtipus=:idtipus or :idtipus is null) and (idfamilia=:idfamilia or :idfamilia is null) and (descripcio like '%' || :descr || '%'  or :descr is null)
    into :idproducte, :codi, :descripcio, :preu,  :idtip, :idfam,:idmarca, :idproveidor
   do suspend;
END

// no va si li passem a descr null
//per exemple: execute procedure buscaProducte(32,8,null)