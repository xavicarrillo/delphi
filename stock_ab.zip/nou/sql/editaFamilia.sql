create procedure editaFamilia(nom varchar(15), idfamilia integer)

as begin
update familia set nom=:nom where idfamilia=:idfamilia;
suspend;
end;