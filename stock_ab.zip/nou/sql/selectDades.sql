alter procedure selectDades(idproducteQueTenim integer)
returns (idp integer, iddades integer, data date, idemp integer, idusuari integer, comentaris varchar (150), idaccio integer, idus integer)
as begin
   for
    select idproducteQueTenim, iddades, data, idemp, idusuari, comentaris, idaccio, idus
      from dades
	  where idproducteQueTenim=:idproducteQueTenim

	     into :idp, :iddades,:data, :idemp, :idusuari, :comentaris, :idaccio, :idus

   do suspend;
END