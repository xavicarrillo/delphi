create procedure SelectProducteComent(comentari varchar (50))
 returns (idProducte integer, idtipus integer, idmarca integer, idproveidor integer, descripcio varchar (150), preu float, idfamilia integer, codi varchar(20), actiu varchar(1))
  as begin
   for
    select idProducte, idtipus, idmarca, idproveidor, descripcio, preu, idfamilia, codi, actiu
      from Producte
	where :comentari  like descripcio
	 into :idProducte, :idtipus, :idmarca, :idproveidor, :descripcio, :preu, :idfamilia, :codi, :actiu
   do suspend;
end