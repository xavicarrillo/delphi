create exception EXCetiqueta "error, el producte ja est� en cua"

create trigger TRI_etiqueta for etiqueta active before insert as 
declare variable caca integer;
begin
 select count (idproductequetenim) from etiqueta where idproductequetenim=new.idproductequetenim into :caca;
 if (caca<>0) then exception EXCetiqueta;
end