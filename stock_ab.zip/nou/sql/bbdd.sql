CREATE DATABASE "c:\projecte\nou\stock.gdb" USER "SYSDBA" PASSWORD "masterkey";

CONNECT "C:\PROJECTE\nou\STOCK.GDB" USER "SYSDBA" PASSWORD "masterkey";


CREATE TABLE EMPRESA
     (
        IDEMPRESA INTEGER NOT NULL,
        nom varchar(20),
	actiu varchar(1),
        PRIMARY KEY (IDEMPRESA)
     );

create table ProducteQueTenim
(
    idProducteQueTenim integer not null primary key,
    idproducte integer not null,
    situacio varchar(10),
    codi_barres varchar(50),
    NS varchar(50),
    estat varchar(1)
);


CREATE TABLE FAMILIA
     (
	idfamilia integer not null primary key,
	nom varchar(15),
	idtipus integer not null,
     );

CREATE TABLE PRODUCTE
     (
        IDPRODUCTE INTEGER NOT NULL,
        idtipus integer not null,
	idmarca integer not null,
	//idmodel integer not null,
	idproveidor integer not null,
	idaccio integer not null,
	idfamilia integer not null,
	actiu varchar(1) default value,
	codi varchar (18),
	codi_barres varchar(20),
	preu float,
	descripcio varchar(150)
	PRIMARY KEY (IDPRODUCTE)
     );

CREATE TABLE ACCIO
     (
	idaccio integer not null,
	nom varchar(50),
	dataInici date,
	dataFi date,
	comentaris varchar(100),
	primary key (idaccio)
     );

CREATE TABLE TIPUS_PRODUCTE
     (
	idtipus integer not null,
	tipus varchar(20),
	PRIMARY KEY (IDTIPUS)
     );

CREATE TABLE MARQUES_PRODUCTE

     (
	idmarca integer not null,
	nom_marca varchar(15),
	PRIMARY KEY (idmarca)
     );

/* CREATE TABLE MODEL
     (
	idmodel integer not null,
	nom varchar(30),
	primary key (idmodel)
     );
*/
CREATE TABLE PROVEIDORS_PRODUCTE
     (
	IDPROVEIDOR INTEGER NOT NULL,
        prov varchar(20),
	PRIMARY KEY (IDPROVEIDOR)
     );

CREATE TABLE USUARI
     (
        IDUSUARI INTEGER NOT NULL,
        nom varchar(30),
	actiu varchar(1),
	PRIMARY KEY (IDUSUARI)
     );

CREATE TABLE ESTATS
     (
	idestat integer not null,
	estat varchar(20),
	primary key (idestat)
     );

CREATE TABLE DADES
     (
        iddades integer not null,
        idemp integer not null,
        idusu integer not null,
        idprod integer not null,
        idestat integer not null,
	data_entrada date,
	data_sortida date,
	primary key (iddades)
     );

alter table PROVEIDORS_PRODUCTE
	add actiu varchar(1);

/* relacionem els identificadors de les taules amb la taula DADES que �s la que cont� la xixa */


ALTER TABLE DADES ADD FOREIGN KEY(idemp) references empresa(idempresa);
ALTER TABLE DADES ADD FOREIGN KEY(idprod) references producte(idproducte);
ALTER TABLE DADES ADD FOREIGN KEY(idusu) references usuari(idusuari);
ALTER TABLE DADES ADD FOREIGN KEY(idestat) references estats(idestat);
alter table producte add foreign key(idfamilia) references familia(idfamilia);

alter table producte add foreign key(idtipus) references tipus_producte(idtipus);
alter table producte add foreign key(idmarca) references marques_producte(idmarca);
alter table producte add foreign key(idmodel) references model(idmodel);
alter table producte add foreign key(idproveidor) references proveidors_producte(idproveidor);
alter table producte add foreign key(idaccio) references accio(idaccio); /* hem va donar un error al passar-ho al interbase (idaccio in use) pero va col.lar */

//aquestes son per relacions mestre-detall:
alter table familia add foreign key (idtipus) references tipus_producte(idtipus)

/* creem els contadors per les taules */
create generator CONT_empresa;
create generator CONT_familia;
create generator CONT_producte;
create generator CONT_producteQueTenim
create generator CONT_usuari;
create generator CONT_dades;
create generator CONT_marques;
create generator CONT_proveidors_producte;
create generator CONT_TIPUS_PRODUCTE;
create generator CONT_MODEL;
create generator CONT_accio;

/* Aquest trigger s'activa avans d'insertar a la taula empresa i fa que el contador CONT_empresa augmenti en 1 l'id de la taula empresa. Totes les taules que tinguin identificador han de dur un trigger*/


SET TERM ^;
/* el set term aquest s'ha de posar sempre davant dels procediments (els triggers ho s�n) */

create trigger TRI_familia for familia active before insert as
begin
new.idfamilia=gen_id(CONT_familia,1);
end^

create trigger TRI_accio for accio active before insert as
begin
new.idaccio=gen_id(CONT_accio,1);
end^

create trigger TRI_empresa for empresa active before insert as
begin
new.idempresa=gen_id(CONT_empresa,1);
end^

create trigger TRI_producte for producte active before insert as
begin
new.idproducte=gen_id(CONT_producte,1);
end^


create trigger TRI_producteQueTenim for producteQueTenim active before insert as
begin
new.idproducteQueTenim=gen_id(CONT_producteQueTenim,1);
end



create trigger TRI_usuari for usuari active before insert as
begin
new.idusuari=gen_id(CONT_usuari,1);
end^

create trigger TRI_MARQUES_PRODUCTE for MARQUES_PRODUCTE active before insert as
begin
new.idmarca=gen_id(CONT_MARQUES,1);
end^

create trigger TRI_proveidors_producte for proveidors_producte active before insert as
begin
new.idproveidor=gen_id(CONT_proveidors_producte,1);
end^

create trigger TRI_TIPUS_PRODUCTE for TIPUS_PRODUCTE active before insert as begin
new.idtipus=gen_id(CONT_TIPUS_PRODUCTE,1);
end^

create trigger TRI_MODEL for MODEL active before insert as begin
new.idMODEL=gen_id(CONT_MODEL,1);
end^

create trigger TRI_DADES for DADES active before insert as begin
new.idDADES=gen_id(CONT_DADES,1);
end^

/* falta el trigger per ESTATS */
SET TERM ;^












