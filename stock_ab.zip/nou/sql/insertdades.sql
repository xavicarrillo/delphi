alter procedure insertdades(idp integer,data date, idaccio integer, idusuari integer, idempresa integer,comentaris varchar(150), idus integer)

returns (iddades integer)
as begin
iddades=GEN_ID(CONT_dades,0)+1;
  insert into dades(iddades, idproductequetenim, data, idaccio, idusuari, idemp, comentaris, idus) values (:iddades, :idp, :data, :idaccio, :idusuari, :idempresa, :comentaris, :idus);

suspend;

end

// execute procedure insertdades(1,'1jan2000',1,2,3,'comentari')