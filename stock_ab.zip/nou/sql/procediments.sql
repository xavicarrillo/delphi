CONNECT "C:\PROJECTE\nou\STOCK.GDB" USER "SYSDBA" PASSWORD "masterkey";

SET TERM ^;

alter procedure buscaProducte(idtipus integer, idfamilia integer) returns (idproducte integer, codi varchar(20), DESCRIPCIO VARCHAR(150), preu float, idtip integer, idfam integer, idmarca integer, idproveidor integer)
 as begin
   for
     select idproducte,codi, descripcio,preu, idtipus, idfamilia, idmarca, idproveidor from producte where (idtipus=:idtipus or :idtipus is null) and (idfamilia=:idfamilia or :idfamilia is null)
    into :idproducte, :codi, :descripcio, :preu,  :idtip, :idfam,:idmarca, :idproveidor
   do suspend;
END


alter procedure insertProducQ (idproducte integer ,situacio varchar(10),ns varchar(50),codi_barres varchar(50), actiu varchar(1), preu float)
returns (idproducteQueTenim integer)
as begin
idproducteQueTenim=GEN_ID(CONT_producteQueTenim,0)+1;

    /*la funcio GEN_ID retorna el contador+el numero que li passem. Si li passessim un 1 li 	sumaria aixo. Ara no ens interessa, perque llavors el sumaria. Volem recollir el valor 	actual i sumar-li 1.*/
 
insert into producteQueTenim(idproducteQueTenim,idproducte, situacio, ns, codi_barres, actiu, preu) values (:idproducteQueTenim,:idproducte, :situacio, :ns, :codi_barres, :actiu, :preu);

suspend; // si retornen algo, fotre-li un suspend; si fos amb un for ficar-li el do (aixi ho fara per cada volta del for)

end

alter procedure insertProducQ (idproducte integer ,situacio varchar(10),ns varchar(50),actiu varchar(1), preu float)
returns (idproducteQueTenim integer)
as
declare variable codi_barres varchar(50);
declare variable codi varchar(20);
 begin
idproducteQueTenim=GEN_ID(CONT_producteQueTenim,0)+1;
select codi from producte where idproducte=:idproducte into :codi;
codi_barres=codi +  idproducteQueTenim;
insert into producteQueTenim(idproducteQueTenim,idproducte, situacio, ns, codi_barres, actiu, preu) values (:idproducteQueTenim,:idproducte, :situacio, :ns, :codi_barres, :actiu, :preu);

suspend; 
end

create procedure select_producte(idtipus integer, idfamilia integer)
returns (idproducte integer,codi varchar(20), descripcio varchar(150))
as begin
   for
    select idproducte,codi, descripcio
      from producte
	  where idtipus=:idtipus and idfamilia=:idfamilia
//or :idtipus is null or :idfamilia is null
	     into :idproducte,:codi,:descripcio
   do suspend;
END

create procedure MostraProducteQueTenim(idproducte integer)
 returns (idproductequetenim integer, situacio varchar (10), codi_barres varchar(50), NS varchar(50), actiu varchar(1), preu float)
  as begin
   for
    select idproductequetenim, situacio, codi_barres, NS, actiu, preu
       from productequetenim where idproducte=:idproducte
       into :idproductequetenim, :situacio, :codi_barres, :NS, :actiu, :preu
   do
   suspend;
end



create procedure select_model(idtipus integer, idmarca integer)
returns (nom varchar(30), idmodel integer)
as begin
   for
    select m.nom,p.idmodel
      from producte p
	join model m on (m.idmodel=p.idmodel) 
	  where p.idtipus=:idtipus and p.idmarca=:idmarca or :idtipus is null or :idmarca is null
	     into :nom,:idmodel
   do suspend;
END^


alter procedure selectfamilia (idtipus integer)
returns (nom varchar(15)) 
as begin
	for
	   select nom from familia
		where idtipus=:idtipus into :nom
	do suspend;
END^


//aquest procedure es per el formulari de manteniment de la taula basica model
create procedure select_model2 (estat varchar(1))
returns (nom varchar(20), actiu varchar(1), idmodel integer) 
as begin
	for
	   select nom, actiu, idmodel
	     from model
		where actiu=:estat or :estat is null into :nom, :estat, :idmodel
	do suspend;
END


alter procedure select_empreses (estat varchar(1))
returns (nom varchar(20), actiu varchar(1), idempresa integer) 
as begin
	for
	   select nom, actiu, idempresa 
	     from empresa
		where actiu=:estat or :estat is null into :nom, :estat, :idempresa
	do suspend;
END^

/*create*/
alter procedure select_usuaris (estat varchar(1))
returns (nom varchar(20), actiu varchar(1), idusuari integer) 
as begin
	for
	   select nom, actiu, idusuari 
	     from usuari
		where actiu=:estat or :estat is null into :nom, :estat, /* li passem el null per si  no li passem cap parametre (en akest cas els agafaria tots)*/
:idusuari
	do suspend;
END^

alter procedure select_proveidors (estat varchar(1))
returns (nom varchar(20), actiu varchar(1), idproveidor integer) 
as begin
	for
	   select prov, actiu, idproveidor 
	     from PROVEIDORS_PRODUCTE
		where actiu=:estat or :estat is null into :nom, :estat, :idproveidor
	do suspend;
END^

alter procedure select_model (estat varchar(1))
returns (nom varchar(25),idmodel integer) 
as begin
	for
	   select nom, idmodel 
	     from model
		where actiu=:estat or :estat is null into :nom, :idmodel
	do suspend;
END

SET TERM ;^






















