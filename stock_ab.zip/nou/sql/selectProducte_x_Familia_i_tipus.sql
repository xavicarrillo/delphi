alter procedure select_producte(idtipus integer, idfamilia integer)
returns (idProducteQueTenim integer, codi varchar(20), NS varchar(50), descripcio varchar (150))
as begin
   for
    select u.idProducteQueTenim,g.codi, u.NS, g.descripcio
      from producte g
	join ProducteQueTenim u on (g.idproducte=u.idProducteQueTenim) 
	  where g.idtipus=:idtipus and g.idfamilia=:idfamilia or :idtipus is null or :idfamilia is null
	     into :idProducteQueTenim,:codi, :NS, :descripcio
   do suspend;
END



